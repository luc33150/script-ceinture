fx_version 'cerulean'
game 'gta5'

author 'Luc'
description 'Script de vérification de ceinture de sécurité avec OX Framework'
version '1.0.0'

client_script 'client.lua'  -- Le chemin vers votre script client

dependency 'ox_lib'  -- Dépendance pour OX library pour les notifications et autres fonctionnalités
'@ox_lib/init.lua'
CreateThread(function()
    local beltOn = false  -- Initialisation de l'état de la ceinture à détachée
    local lastSoundTime = 0  -- Temps auquel le dernier son a été joué

    while true do
        Wait(0)
        local playerPed = PlayerPedId()

        if IsPedSittingInAnyVehicle(playerPed) then
            local vehicle = GetVehiclePedIsIn(playerPed, false)
            if GetPedInVehicleSeat(vehicle, -1) == playerPed then -- le joueur est le conducteur
                if IsControlJustPressed(0, 311) then -- 311 correspond à la touche K
                    beltOn = not beltOn  -- Changement de l'état de la ceinture
                    SetPedConfigFlag(playerPed, 32, not beltOn)  -- Met à jour le flag pour permettre ou empêcher l'éjection

                    if beltOn then
                        exports.ox_lib:notify({
                            title = 'Ceinture de sécurité',
                            description = 'Ceinture attachée',
                            type = 'success'
                        })
                    else
                        exports.ox_lib:notify({
                            title = 'Ceinture de sécurité',
                            description = 'Ceinture détachée',
                            type = 'error'
                        })
                        lastSoundTime = GetGameTimer()  -- Réinitialiser le timer du son
                    end
                end
                -- Jouer le son si la ceinture est détachée et que 1 seconde s'est écoulée
                if not beltOn and (GetGameTimer() - lastSoundTime) > 1000 then
                    PlaySoundFrontend(-1, "CHECKPOINT_MISSED", "HUD_MINI_GAME_SOUNDSET", false)
                    lastSoundTime = GetGameTimer()  -- Réinitialiser le timer du son
                end
            end
        end
    end
end)
